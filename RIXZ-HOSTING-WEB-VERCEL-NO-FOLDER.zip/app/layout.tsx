import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"Rixz Hosting — VPS & Premium Store",description:"Order VPS dan akun premium dengan pembayaran QRIS otomatis."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body>{children}</body></html>}
