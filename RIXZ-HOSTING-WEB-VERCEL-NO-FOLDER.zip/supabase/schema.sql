-- Run this entire file in Supabase SQL Editor before deploying.
create extension if not exists pgcrypto;
create table if not exists public.orders (
 id text primary key, product_id text not null, product_name text not null, product_type text not null check (product_type in ('vps','premium')),
 amount integer not null check (amount >= 1000), contact text not null, lookup_hash text not null,
 transaction_id text unique, payment_amount integer, qr_image text, branding jsonb default '{}'::jsonb,
 payment_status text not null default 'creating', fulfillment_status text not null default 'waiting',
 fulfillment_result jsonb, fulfillment_error text, created_at timestamptz not null default now(), expires_at timestamptz, paid_at timestamptz, fulfilled_at timestamptz
);
create index if not exists orders_created_at_idx on public.orders(created_at desc);
create table if not exists public.premium_stock (
 id uuid primary key default gen_random_uuid(), product_id text not null, account_data text not null,
 status text not null default 'available' check (status in ('available','sold')), order_id text references public.orders(id), created_at timestamptz not null default now(), sold_at timestamptz
);
create index if not exists premium_stock_available_idx on public.premium_stock(product_id,status,created_at);
-- Atomic one-time fulfillment claim to prevent duplicate provisioning on webhook + polling races.
create or replace function public.claim_order_fulfillment(p_order_id text) returns boolean language plpgsql security definer set search_path=public as $$
declare n integer;
begin update orders set fulfillment_status='processing' where id=p_order_id and payment_status='paid' and fulfillment_status in ('waiting','failed'); get diagnostics n=row_count; return n=1; end; $$;
-- Atomically reserve one premium account for a paid order.
create or replace function public.claim_premium_stock(p_product_id text,p_order_id text) returns jsonb language plpgsql security definer set search_path=public as $$
declare s premium_stock%rowtype;
begin select * into s from premium_stock where product_id=p_product_id and status='available' order by created_at for update skip locked limit 1;
 if not found then return null; end if;
 update premium_stock set status='sold',order_id=p_order_id,sold_at=now() where id=s.id;
 return jsonb_build_object('stock_id',s.id,'account_data',s.account_data);
end; $$;
-- Restrict RPC execution to the backend service role.
revoke all on function public.claim_order_fulfillment(text) from public, anon, authenticated;
revoke all on function public.claim_premium_stock(text,text) from public, anon, authenticated;
grant execute on function public.claim_order_fulfillment(text) to service_role;
grant execute on function public.claim_premium_stock(text,text) to service_role;
-- The service-role key is used only in server routes. Do not expose it in browser code.
alter table public.orders enable row level security;
alter table public.premium_stock enable row level security;
