import { createClient } from "@supabase/supabase-js";
export function db(){
 const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key) throw new Error("SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY belum diatur");
 return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
}
