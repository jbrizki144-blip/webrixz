import { db } from "@/lib/db";
import { VPS_PLANS, findProduct } from "@/lib/catalog";
import { randomBytes } from "node:crypto";
const rand=(n=18)=>randomBytes(n).toString("base64url");
async function claim(orderId:string){const {data,error}=await db().rpc("claim_order_fulfillment",{p_order_id:orderId});if(error)throw error;return data===true||data?.claimed===true}
async function finish(orderId:string,result:unknown){const {error}=await db().from("orders").update({fulfillment_status:"fulfilled",fulfillment_result:result,fulfilled_at:new Date().toISOString()}).eq("id",orderId);if(error)throw error}
async function fail(orderId:string,message:string){await db().from("orders").update({fulfillment_status:"failed",fulfillment_error:message.slice(0,900)}).eq("id",orderId)}
export async function fulfillPaidOrder(orderId:string){
 const client=db();const {data:order,error}=await client.from("orders").select("*").eq("id",orderId).single();if(error||!order)throw new Error("Order tidak ditemukan");if(order.payment_status!=="paid"||order.fulfillment_status==="fulfilled")return;
 if(!await claim(orderId))return;
 try{
  const product=findProduct(order.product_id);if(!product)throw new Error("Produk tidak ditemukan di katalog");
  if(order.product_type==="premium"){
   const {data:stock,error:stockError}=await client.rpc("claim_premium_stock",{p_product_id:order.product_id,p_order_id:orderId});if(stockError)throw stockError;if(!stock)throw new Error("Stok akun premium habis. Hubungi admin untuk refund/penggantian.");
   await finish(orderId,{type:"premium",account:stock.account_data});return;
  }
  const plan=VPS_PLANS.find(p=>p.id===order.product_id);if(!plan)throw new Error("Paket VPS tidak ditemukan");
  let result:any;
  if(plan.provider==="digitalocean") result=await createDO(plan,order);
  else if(plan.provider==="linode") result=await createLinode(plan,order);
  else result=await createPterodactyl(plan,order);
  await finish(orderId,{type:"vps",provider:plan.provider,server:result});
 }catch(e:any){await fail(orderId,e?.message||"Provisioning gagal");throw e}
}
async function createDO(plan:any,order:any){const token=process.env.DIGITALOCEAN_TOKEN;if(!token)throw new Error("DIGITALOCEAN_TOKEN belum diatur");const password=rand(16)+"A1!";const name=`rixz-${order.id.slice(0,10)}`;const userData=`#cloud-config\nssh_pwauth: true\nchpasswd:\n  expire: false\n  users:\n    - name: root\n      password: ${password}\n      type: text\nruncmd:\n  - sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config\n  - systemctl restart ssh || systemctl restart sshd\n`;
 const r=await fetch("https://api.digitalocean.com/v2/droplets",{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({name,region:plan.region,size:plan.size,image:plan.image,ipv6:true,monitoring:true,user_data:userData,tags:["rixz-hosting"]}),signal:AbortSignal.timeout(30000)});const d=await r.json();if(!r.ok)throw new Error(d.message||"DigitalOcean gagal membuat Droplet");return {id:d.droplet?.id,name,ip:d.droplet?.networks?.v4?.find((x:any)=>x.type==="public")?.ip_address||"Menunggu provisioning",username:"root",password,status:d.droplet?.status||"new"};}
async function createLinode(plan:any,order:any){const token=process.env.LINODE_TOKEN;if(!token)throw new Error("LINODE_TOKEN belum diatur");const password=rand(16)+"A1!";const r=await fetch("https://api.linode.com/v4/linode/instances",{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({label:`rixz-${order.id.slice(0,10)}`,region:plan.region,type:plan.size,image:plan.image,root_pass:password,tags:["rixz-hosting"]}),signal:AbortSignal.timeout(30000)});const d=await r.json();if(!r.ok)throw new Error(d.errors?.[0]?.reason||"Linode gagal membuat instance");return {id:d.id,label:d.label,ip:d.ipv4?.[0]||"Menunggu provisioning",username:"root",password,status:d.status};}
function parsePanelEnvironment(){try{return JSON.parse(process.env.PTERODACTYL_ENV_JSON||"{}")}catch{throw new Error("PTERODACTYL_ENV_JSON harus berupa JSON valid")}}
async function createPterodactyl(plan:any,order:any){const url=process.env.PTERODACTYL_URL?.replace(/\/$/,"");const key=process.env.PTERODACTYL_APPLICATION_KEY;if(!url||!key)throw new Error("PTERODACTYL_URL / PTERODACTYL_APPLICATION_KEY belum diatur");const email=`${order.id.slice(0,12)}@customer.invalid`;const username=`u${order.id.replace(/-/g,"").slice(0,12)}`;const password=rand(15)+"A1!";
 const userRes=await fetch(`${url}/api/application/users`,{method:"POST",headers:{Authorization:`Bearer ${key}`,Accept:"Application/vnd.pterodactyl.v1+json","Content-Type":"application/json"},body:JSON.stringify({email,username,first_name:"Rixz",last_name:"Customer",password}),signal:AbortSignal.timeout(20000)});let ud=await userRes.json();if(!userRes.ok)throw new Error(ud.errors?.[0]?.detail||"Gagal membuat user Pterodactyl");const userId=ud.attributes?.id;
 const nest=Number(process.env.PTERODACTYL_NEST_ID||plan.nestId||1),egg=Number(process.env.PTERODACTYL_EGG_ID||plan.eggId||0),location=Number(process.env.PTERODACTYL_LOCATION_ID||plan.locationId||0);if(!egg||!location)throw new Error("Atur PTERODACTYL_EGG_ID dan PTERODACTYL_LOCATION_ID");
 const serverRes=await fetch(`${url}/api/application/servers`,{method:"POST",headers:{Authorization:`Bearer ${key}`,Accept:"Application/vnd.pterodactyl.v1+json","Content-Type":"application/json"},body:JSON.stringify({name:`Rixz-${order.id.slice(0,8)}`,user:userId,egg, docker_image:process.env.PTERODACTYL_DOCKER_IMAGE||"ghcr.io/parkervcp/yolks:nodejs_20",startup:process.env.PTERODACTYL_STARTUP||"npm start",environment:parsePanelEnvironment(),limits:{memory:plan.ramGb*1024,disk:plan.diskGb,cpu:plan.cpu,swap:0,io:500},feature_limits:{databases:0,allocations:1,backups:0},deploy:{locations:[location],dedicated_ip:false,port_range:[]}}),signal:AbortSignal.timeout(30000)});const sd=await serverRes.json();if(!serverRes.ok)throw new Error(sd.errors?.[0]?.detail||"Gagal membuat server Pterodactyl");return {panel:url,server_id:sd.attributes?.id,identifier:sd.attributes?.identifier,username,email,password};}
