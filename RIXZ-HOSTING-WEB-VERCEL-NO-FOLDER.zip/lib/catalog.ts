export type VpsPlan = { id:string; name:string; description:string; price:number; provider:"digitalocean"|"linode"|"pterodactyl"; region:string; size:string; image:string; ramGb:number; diskGb:number; cpu:number; nestId?:number; eggId?:number; locationId?:number; dockerImage?:string; startup?:string; environment?:Record<string,string> };
export type PremiumProduct = { id:string; name:string; description:string; price:number; duration:string; category:string };
// Edit these demo plans and prices before launch. Provider IDs must match your provider account.
export const VPS_PLANS: VpsPlan[] = [
 {id:"vps-do-2gb",name:"VPS DigitalOcean 2GB",description:"1 vCPU • 2 GB RAM • 50 GB SSD",price:45000,provider:"digitalocean",region:"sgp1",size:"s-1vcpu-2gb",image:"ubuntu-24-04-x64",ramGb:2,diskGb:50,cpu:1},
 {id:"vps-linode-4gb",name:"VPS Linode 4GB",description:"2 CPU • 4 GB RAM • 80 GB SSD",price:85000,provider:"linode",region:"ap-south",size:"g6-standard-2",image:"linode/ubuntu24.04",ramGb:4,diskGb:80,cpu:2},
 {id:"vps-panel-2gb",name:"VPS Pterodactyl 2GB",description:"2 GB RAM • 2 GB swap • 20 GB disk",price:25000,provider:"pterodactyl",region:"panel",size:"2gb",image:"docker",ramGb:2,diskGb:20,cpu:100}
];
export const PREMIUM_PRODUCTS: PremiumProduct[] = [
 {id:"netflix-1m",name:"Netflix Premium 1 Bulan",description:"Akun premium — stok dikirim otomatis",price:25000,duration:"1 Bulan",category:"Streaming"},
 {id:"spotify-1m",name:"Spotify Premium 1 Bulan",description:"Akun premium — stok dikirim otomatis",price:15000,duration:"1 Bulan",category:"Music"},
 {id:"canva-1m",name:"Canva Pro 1 Bulan",description:"Akun premium — stok dikirim otomatis",price:12000,duration:"1 Bulan",category:"Productivity"},
 {id:"youtube-1m",name:"YouTube Premium 1 Bulan",description:"Akun premium — stok dikirim otomatis",price:18000,duration:"1 Bulan",category:"Streaming"}
];
export function findProduct(id:string) { return [...VPS_PLANS,...PREMIUM_PRODUCTS].find(p=>p.id===id); }
export function formatIDR(value:number) { return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(value); }
